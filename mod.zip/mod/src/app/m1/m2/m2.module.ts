import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Comp12Component } from './comp12/comp12.component';



@NgModule({
  declarations: [Comp12Component],
  imports: [
    CommonModule
  ],
  exports:[Comp12Component]
})
export class M2Module { }
