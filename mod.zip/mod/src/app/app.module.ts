import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {M1Module} from './m1/m1.module';
import { ChildComponent } from './child/child.component';


@NgModule({
  declarations: [
    AppComponent,
    ChildComponent
  ],
  imports: [
    BrowserModule,M1Module
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
