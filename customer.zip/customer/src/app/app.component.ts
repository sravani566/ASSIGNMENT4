import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  userData=[
    {"id":1,"name":"Raj"},
    {"id":2,"name":"John"},
    {"id":3,"name":"Pooja"}
  ];

  data(user: any){
    alert(` UserName : ${user.name} Address : ${user.address}`);
    
  }
  title = 'example of data communication ' ;

  
}